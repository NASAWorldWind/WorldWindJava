README for DSDK WPF Viewer Example
==================================

Unzip this package into the SDKROOT\examples\src directory of the SDK.

Compile and execute, using the directory SDKROOT\examples as your
working directory.  Before execution you must copy the appropriate
lti_dsdk_* DLLs from the SDK's lib directory to the WPFViewer.exe's
build output directory.

The program should be able to open and display the upperleft corner
of MrSID images (that are RGB and are at least 320x240 pixels).

