using System.Reflection;
using System.Security.Permissions;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyTitle("LizardTech.SampleWpfViewer")]
[assembly: AssemblyProduct("LizardTech.SampleWpfViewer")]
[assembly: AssemblyDescription("(For technical support, see www.lizardtech.com/support.)")]
[assembly: AssemblyCompany("LizardTech")]
[assembly: AssemblyCopyright("Copyright � LizardTech 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
