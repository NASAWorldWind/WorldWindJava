var a00136 =
[
    [ "J2KErrorDisposition", "a00136.html#a931c1af5030f88d6c2f0ac0fa2cbf3fe", [
      [ "J2K_ERROR_DISPOSTION_IGNORE", "a00136.html#a931c1af5030f88d6c2f0ac0fa2cbf3fea1bf64fa9a36608c71e6cecb153186891", null ],
      [ "J2K_ERROR_DISPOSTION_STDERR", "a00136.html#a931c1af5030f88d6c2f0ac0fa2cbf3feabf2eb14974566703a020546838f61571", null ],
      [ "J2K_ERROR_DISPOSTION_THROW", "a00136.html#a931c1af5030f88d6c2f0ac0fa2cbf3feab84fdc3c64aabe2123fd60eff21312ab", null ]
    ] ],
    [ "J2KFileFormat", "a00136.html#a0203e29ce2f3f6eaf4085e91cb1aba67", [
      [ "J2K_FILEFORMAT_INVALID", "a00136.html#a0203e29ce2f3f6eaf4085e91cb1aba67af651ec4e3e63bfef7e4e5a7c7daf2816", null ],
      [ "J2K_FILEFORMAT_JPC", "a00136.html#a0203e29ce2f3f6eaf4085e91cb1aba67ac5307c4772b5f34267a3d8e8266c6fbf", null ],
      [ "J2K_FILEFORMAT_JP2", "a00136.html#a0203e29ce2f3f6eaf4085e91cb1aba67a7d49059c526080e8626683feb58fb359", null ],
      [ "J2K_FILEFORMAT_JPX", "a00136.html#a0203e29ce2f3f6eaf4085e91cb1aba67aebd0fae11f3f1b88072c13386ebfee7d", null ]
    ] ],
    [ "J2KProfile", "a00136.html#ac07a2835dc69c14f0c96f33895152408", [
      [ "J2K_PROFILE_DEFAULT", "a00136.html#ac07a2835dc69c14f0c96f33895152408aaf1f622db7ef59e66c6a4cfa9b52ea72", null ],
      [ "J2K_PROFILE_0", "a00136.html#ac07a2835dc69c14f0c96f33895152408a88609ec434e1f0e51a363ccfe5bd8cc5", null ],
      [ "J2K_PROFILE_1", "a00136.html#ac07a2835dc69c14f0c96f33895152408ad640773d129a9dc73207e2fd15885c81", null ],
      [ "J2K_PROFILE_2", "a00136.html#ac07a2835dc69c14f0c96f33895152408aa06e885a5f420d081ef7563871887985", null ],
      [ "J2K_PROFILE_CINEMA2K", "a00136.html#ac07a2835dc69c14f0c96f33895152408ae653821dd30ba676ccb2c365eeedb090", null ],
      [ "J2K_PROFILE_CINEMA4K", "a00136.html#ac07a2835dc69c14f0c96f33895152408ab081df9e207269daca3be16189e27e8e", null ],
      [ "J2K_PROFILE_PART2", "a00136.html#ac07a2835dc69c14f0c96f33895152408a2897878e82cd14a0f28704bffe52c3e2", null ]
    ] ],
    [ "J2KProgressionOrder", "a00136.html#a81f66a44f207cb1013037cbf91ada7db", [
      [ "J2K_ORDER_INVALID", "a00136.html#a81f66a44f207cb1013037cbf91ada7dba601919e4233af61b47ce996b7bd20dd9", null ],
      [ "J2K_ORDER_LRCP", "a00136.html#a81f66a44f207cb1013037cbf91ada7dbadd1d87c8ee2b20a221f84d0120ed428a", null ],
      [ "J2K_ORDER_RLCP", "a00136.html#a81f66a44f207cb1013037cbf91ada7dba3e632727de4359639c9b648902dc5dac", null ],
      [ "J2K_ORDER_RPCL", "a00136.html#a81f66a44f207cb1013037cbf91ada7dbab6cb468b9c1d3fb18ab73728b1c9c498", null ],
      [ "J2K_ORDER_PCRL", "a00136.html#a81f66a44f207cb1013037cbf91ada7dba0af5dda0e1c91127e3d263bdb34dc8b1", null ],
      [ "J2K_ORDER_CPRL", "a00136.html#a81f66a44f207cb1013037cbf91ada7dba0a8ba57a8ea9077ba9a6a52f4a8c2ec7", null ]
    ] ],
    [ "J2KTilePartFlags", "a00136.html#a32fc3a949b814b666806ed1795d2170e", [
      [ "J2K_TILEPART_FLAG_NONE", "a00136.html#a32fc3a949b814b666806ed1795d2170ea4052de4d3479ec56e2e3c15a5c6ec960", null ],
      [ "J2K_TILEPART_FLAG_R", "a00136.html#a32fc3a949b814b666806ed1795d2170ea9d8e990c7a6fd85b5e3147f74a7bf126", null ],
      [ "J2K_TILEPART_FLAG_L", "a00136.html#a32fc3a949b814b666806ed1795d2170ea165f6dc805e194f96d5876f936e04f1c", null ],
      [ "J2K_TILEPART_FLAG_C", "a00136.html#a32fc3a949b814b666806ed1795d2170eac87f95d47011dd0ac194820a171a62ec", null ],
      [ "J2K_TILEPART_FLAG_MAX", "a00136.html#a32fc3a949b814b666806ed1795d2170eaae606a0db7747bd955ded70bce55c6f6", null ]
    ] ]
];