var a00092 =
[
    [ "LTIOverridePixelPropsData", "a00092.html#a2e5a31cee80957a9c85c370caf5e0b3a", null ],
    [ "~LTIOverridePixelPropsData", "a00092.html#addbd135837826b1d34dca1d000d7e7d4", null ],
    [ "setDefaultDynamicRange", "a00092.html#acf37baf3454a54ed0cc8f6f8e2f12478", null ],
    [ "setDynamicRange", "a00092.html#a4952540555a7bcba23b5c0b1d61676a0", null ],
    [ "setPixelBPS", "a00092.html#af551e2fb8897602ad23fde0533a1e1db", null ],
    [ "setPixelProps", "a00092.html#aa1c7af12487719ece2516d31b8aeea0a", null ],
    [ "m_drmaxPixel", "a00092.html#a814a26f39cc61790fc8bcb7bffb8423e", null ],
    [ "m_drminPixel", "a00092.html#a69e6361f62f0f6c59a9792f3c507d840", null ],
    [ "m_pixelProps", "a00092.html#a2268681e9921304cd528727ddf2c3f5a", null ]
];