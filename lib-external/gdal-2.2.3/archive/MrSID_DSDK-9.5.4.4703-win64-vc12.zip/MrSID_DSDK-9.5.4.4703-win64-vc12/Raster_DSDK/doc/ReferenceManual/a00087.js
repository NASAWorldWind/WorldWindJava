var a00087 =
[
    [ "getMetadata", "a00087.html#aa52c0d4c6de2088870b0688b47c4f482", null ],
    [ "overrideMetadata", "a00087.html#ac36d5e3362c45054714a6de7d0b4f93e", null ]
];