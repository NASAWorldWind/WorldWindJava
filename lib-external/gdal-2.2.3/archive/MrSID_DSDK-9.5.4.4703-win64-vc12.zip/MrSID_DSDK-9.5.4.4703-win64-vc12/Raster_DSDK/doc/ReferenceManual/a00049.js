var a00049 =
[
    [ "LTIGeomDim", "a00049.html#a3141920feaeaf7925d6ac07748b7233c", null ],
    [ "LTIGeomDim", "a00049.html#aea498eeae71a007dbdd7235deca88c4e", null ],
    [ "operator!=", "a00049.html#a937a30ab48beef1531cfae748b91f183", null ],
    [ "operator=", "a00049.html#a9939e180f01e1e56ce47d6530dc38c62", null ],
    [ "operator==", "a00049.html#ad3e81d89f9dc90ad5a77bd9ab7a1ed30", null ],
    [ "height", "a00049.html#a42f8a84c4551680f26fb82dfdb9db12b", null ],
    [ "width", "a00049.html#a0882a33c28320f26698e622911e6c529", null ]
];