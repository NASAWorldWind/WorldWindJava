var a00088 =
[
    [ "LTIOverrideMetadataData", "a00088.html#a4c6a4b15dc7c0b10656cad29a421a2ae", null ],
    [ "~LTIOverrideMetadataData", "a00088.html#a33ae7ba7c9eb54138fea7e50df5b5470", null ],
    [ "createMetadata", "a00088.html#ab5bc84309e15fe1a7c5404901fcda88a", null ],
    [ "getMetadata", "a00088.html#add0a7c921f300dff233a879129696d71", null ],
    [ "m_metadata", "a00088.html#ac03ba0b23abce008f014378e01d68c11", null ]
];