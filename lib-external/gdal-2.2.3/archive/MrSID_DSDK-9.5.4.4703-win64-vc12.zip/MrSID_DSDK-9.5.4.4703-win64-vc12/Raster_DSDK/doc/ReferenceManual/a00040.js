var a00040 =
[
    [ "LTIColorTransformer", "a00040.html#ad91d4aec04360f9ced47729a65f5e145", null ],
    [ "~LTIColorTransformer", "a00040.html#a275210ec7aa91a2926028759c8de2ae9", null ],
    [ "create", "a00040.html#af451d8ca15d38681752222117b59fbbb", null ],
    [ "decodeBegin", "a00040.html#a63507bde313d7e7cdea7261675f8e7f8", null ],
    [ "decodeEnd", "a00040.html#a5bf3498ab29beee066efc98e204fb4b9", null ],
    [ "decodeStrip", "a00040.html#a1de9efbb2272896e611d92ff87771747", null ],
    [ "getModifications", "a00040.html#a432a43dca3e1660dd82f2cf3933f7ed9", null ],
    [ "initialize", "a00040.html#a6e993088e8ccfd978bd739350310ff02", null ],
    [ "isSupportedTransform", "a00040.html#a9c1021d990d7e95979ae830932987b48", null ],
    [ "push", "a00040.html#a001ed010f84231be6eb84883d10cc63f", null ],
    [ "transformBuffer", "a00040.html#a881cf111d68bed1ae6af0de3f4dafc7a", null ],
    [ "transformPixel", "a00040.html#afc150b64f24eb26c2e5d36f0f5ef674a", null ]
];