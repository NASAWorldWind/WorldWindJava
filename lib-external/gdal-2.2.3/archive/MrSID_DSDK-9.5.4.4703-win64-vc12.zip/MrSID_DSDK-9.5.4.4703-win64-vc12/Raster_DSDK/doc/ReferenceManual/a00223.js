var a00223 =
[
    [ "Format", "a00223.html#a9ae908bb978859487c95cde8222fbb5e", [
      [ "FORMAT_INVALID", "a00223.html#a9ae908bb978859487c95cde8222fbb5eaf4335163e2c3383920dce4f279bc691a", null ],
      [ "FORMAT_RAW", "a00223.html#a9ae908bb978859487c95cde8222fbb5ea664d6afb31f56accce0aaa96d9bede69", null ],
      [ "FORMAT_BILEVEL", "a00223.html#a9ae908bb978859487c95cde8222fbb5ea9730b183621ac2962533e11b2dc340f6", null ],
      [ "FORMAT_JPEG", "a00223.html#a9ae908bb978859487c95cde8222fbb5eada2cecb40fe21794e2e84050e7709757", null ],
      [ "FORMAT_VQ", "a00223.html#a9ae908bb978859487c95cde8222fbb5ea9507998dc38a1840bb5aa6975677e791", null ],
      [ "FORMAT_JPEGLS", "a00223.html#a9ae908bb978859487c95cde8222fbb5eaafb05bf93626704bc7e81a4b0986b1d7", null ],
      [ "FORMAT_JPEGDS", "a00223.html#a9ae908bb978859487c95cde8222fbb5eae136efa55f0d2ea8f4169299bfd47c71", null ],
      [ "FORMAT_JP2", "a00223.html#a9ae908bb978859487c95cde8222fbb5eae6d98fa8ccc216cbb11205b8b1c46b77", null ]
    ] ],
    [ "J2klraOrigin", "a00223.html#acf181b0a0e55e4e22367eac7a78613cd", [
      [ "J2KLRA_ORIGINAL_NPJE", "a00223.html#acf181b0a0e55e4e22367eac7a78613cda94e00137123fa2948752305a2245ce58", null ],
      [ "J2KLRA_PARSED_NPJE", "a00223.html#acf181b0a0e55e4e22367eac7a78613cda5c3c9adec4331c22d2b19451e9f2bdf3", null ],
      [ "J2KLRA_ORIGINAL_EPJE", "a00223.html#acf181b0a0e55e4e22367eac7a78613cdae72e3825b87ff1628e6cacc3be9f4f49", null ],
      [ "J2KLRA_PARSED_EPJE", "a00223.html#acf181b0a0e55e4e22367eac7a78613cda72c721588cf0d0ad70e373c45adc288a", null ],
      [ "J2KLRA_ORIGINAL_TPJE", "a00223.html#acf181b0a0e55e4e22367eac7a78613cdab64c55d29ab4d68539a0d8dcb9ef6db1", null ],
      [ "J2KLRA_PARSED_TPJE", "a00223.html#acf181b0a0e55e4e22367eac7a78613cda8e1d1e3e3c6216f6641f82e7072d5065", null ],
      [ "J2KLRA_ORIGINAL_LPJE", "a00223.html#acf181b0a0e55e4e22367eac7a78613cda1e73a85d83d9de75430d53fde5f77eaa", null ],
      [ "J2KLRA_PARSED_LPJE", "a00223.html#acf181b0a0e55e4e22367eac7a78613cda83647afafd431bf6af0ca8e9ea5350cf", null ],
      [ "J2KLRA_ORIGINAL_OTHER", "a00223.html#acf181b0a0e55e4e22367eac7a78613cda7deb34640621f26ed7b39226e25db441", null ],
      [ "J2KLRA_PARSED_OTHER", "a00223.html#acf181b0a0e55e4e22367eac7a78613cdaef60728e86e56132fa90d9e11b621d8f", null ]
    ] ],
    [ "Layout", "a00223.html#a51f092682432028b7eb3ec43492ca8d0", [
      [ "LAYOUT_INVALID", "a00223.html#a51f092682432028b7eb3ec43492ca8d0acf94cf5ae9bad63faa75a148a52d6400", null ],
      [ "LAYOUT_BLOCK", "a00223.html#a51f092682432028b7eb3ec43492ca8d0abb6d3002f1b66c41b3d96b36c3bb5a38", null ],
      [ "LAYOUT_PIXEL", "a00223.html#a51f092682432028b7eb3ec43492ca8d0a9cb282369d509967e11fbf463a79d388", null ],
      [ "LAYOUT_ROW", "a00223.html#a51f092682432028b7eb3ec43492ca8d0a9b3c6cfee0cd8be2e86d43d46c23dadf", null ],
      [ "LAYOUT_SEQ", "a00223.html#a51f092682432028b7eb3ec43492ca8d0a5f4e7aeb40267b2af8b987165456f863", null ]
    ] ],
    [ "TRELocation", "a00223.html#aa615225bc5c2ea6793d9f0e77a476749", [
      [ "TRE_OMIT", "a00223.html#aa615225bc5c2ea6793d9f0e77a476749ad7ad45faa2ec298563fb21ac3a8fd4cb", null ],
      [ "TRE_USER", "a00223.html#aa615225bc5c2ea6793d9f0e77a476749a150366b0174d3881f5744c4bb5eba3cb", null ],
      [ "TRE_EXTENDED", "a00223.html#aa615225bc5c2ea6793d9f0e77a476749a5f1e541e6db943042e4ef84f22a9369a", null ]
    ] ],
    [ "Version", "a00223.html#aa091805c4142ea4fac9b52141a6e9368", [
      [ "VERSION_INVALID", "a00223.html#aa091805c4142ea4fac9b52141a6e9368ae9b391fc0c2f6d2a663c6a9e3225cdc0", null ],
      [ "VERSION_11", "a00223.html#aa091805c4142ea4fac9b52141a6e9368a32f09396b121582324e7bd816265476c", null ],
      [ "VERSION_20", "a00223.html#aa091805c4142ea4fac9b52141a6e9368aa82856a5fb75ceee1ef265876f66d4b4", null ],
      [ "VERSION_21", "a00223.html#aa091805c4142ea4fac9b52141a6e9368a82759b5becf4d57d046bc01cb44f4c76", null ]
    ] ]
];