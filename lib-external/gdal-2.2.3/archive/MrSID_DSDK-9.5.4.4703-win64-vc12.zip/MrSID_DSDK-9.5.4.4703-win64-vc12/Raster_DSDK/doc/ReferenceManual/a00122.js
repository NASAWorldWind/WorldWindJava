var a00122 =
[
    [ "TextSegment", "a00122.html#a8bc6af152a373cefd804012de9fb021e", null ],
    [ "~TextSegment", "a00122.html#a050092dba3d9fe41ae95902c72b7cf4f", null ],
    [ "addMetadataLocal", "a00122.html#a69d2e54e1061ffdf4eb41c00553ef6b3", null ],
    [ "getTextData", "a00122.html#a2ad4f6064ee9671c738ca92c94666c09", null ],
    [ "getTextDataLength", "a00122.html#a014730cadd4fd5adafd8d60cd00bb3e6", null ],
    [ "initialize", "a00122.html#ac7565ea13ff235ef3162af392581a0a6", null ]
];