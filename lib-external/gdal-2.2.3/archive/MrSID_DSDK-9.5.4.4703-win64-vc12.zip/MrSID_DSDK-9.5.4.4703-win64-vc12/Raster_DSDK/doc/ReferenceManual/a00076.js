var a00076 =
[
    [ "LTIOverrideBackgroundPixelData", "a00076.html#a03278d71d26070723e82c8c6dea08df6", null ],
    [ "~LTIOverrideBackgroundPixelData", "a00076.html#ad92db97fbe8f78e182092df434391efd", null ],
    [ "setBackgroundPixel", "a00076.html#a68ac3be7ac59f14f73841025cbecfb56", null ],
    [ "setNoDataPixel", "a00076.html#aff5179d75f8c1aaa5d9a4c35f2308519", null ],
    [ "m_backgroundPixel", "a00076.html#aad348961a99587c1e7bdb3a57dc64fc8", null ],
    [ "m_nodataPixel", "a00076.html#af28fc503554ce03f098c1012f850df35", null ]
];