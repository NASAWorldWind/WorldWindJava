var a00075 =
[
    [ "getBackgroundPixel", "a00075.html#a854cbbc61181dbc0b0d987e924626f93", null ],
    [ "getNoDataPixel", "a00075.html#ad7cb50f9f00ad77fd11801ad7b13c674", null ],
    [ "overrideBackgroundPixel", "a00075.html#a62bcee5a53538408f18c030eb9af3238", null ],
    [ "overrideNoDataPixel", "a00075.html#ac468bfe9d4a74fa6369df1091e316f38", null ]
];