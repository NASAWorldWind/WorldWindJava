var a00195 =
[
    [ "LTI_STS_MrSIDReaders_BadBandList", "a00195.html#a67e0851c1ccbfc97c5bd653a92c99dd8", null ],
    [ "LTI_STS_MrSIDReaders_BadFileFormat", "a00195.html#a88aa1a1bb25af2d184b351f93a75ee50", null ],
    [ "LTI_STS_MrSIDReaders_BadMG2letInit", "a00195.html#a22273c5d5ba037cc707587e9791d1b75", null ],
    [ "LTI_STS_MrSIDReaders_BadMG3letInit", "a00195.html#ab076320ad0a259788a9e1720318d8ffb", null ],
    [ "LTI_STS_MrSIDReaders_BadSidletFormat", "a00195.html#ad08143b05dbed17f95e0d0e40629fca0", null ],
    [ "LTI_STS_MrSIDReaders_BandListOnlyForMG4", "a00195.html#a313227787fa74155dae3a5b880f902a3", null ],
    [ "LTI_STS_MrSIDReaders_Base", "a00195.html#a42a9083822a0cc2881efb329e02f190a", null ],
    [ "LTI_STS_MrSIDReaders_CannotOpenFile", "a00195.html#aeef35f5781d24ee1e50c07b4d4e9a2b7", null ],
    [ "LTI_STS_MrSIDReaders_ColorSpace_NumBandsMismatch", "a00195.html#a3922cd0470b6bee2b0cacc1bd34827c5", null ],
    [ "LTI_STS_MrSIDReaders_InvalidMemoryModel", "a00195.html#aa62177921b71fac1cef00ca14b43629b", null ],
    [ "LTI_STS_MrSIDReaders_InvalidMetadata", "a00195.html#a31809f5850261e9f0ed8f684e716428d", null ],
    [ "LTI_STS_MrSIDReaders_InvalidStripHeight", "a00195.html#a607527669dad4b289d6d6c5c455121bb", null ],
    [ "LTI_STS_MrSIDReaders_Max", "a00195.html#a191bd3ff5186793f297aede246df4b18", null ],
    [ "LTI_STS_MrSIDReaders_MetadataReadError", "a00195.html#ae24f76a3cf3c6ae4ccc153b5c8f232aa", null ],
    [ "LTI_STS_MrSIDReaders_MG2Error", "a00195.html#ae36d42fa6be5367a69f96a7b6d55b4e4", null ],
    [ "LTI_STS_MrSIDReaders_UnknownTileImageFormat", "a00195.html#a86d535df38a5bb437d13810b1e545879", null ],
    [ "LTI_STS_MrSIDReaders_UnsupColorSpace", "a00195.html#ae961d27e4d9086beeafceae9ee0f01aa", null ],
    [ "LTI_STS_MrSIDReaders_UnsupDataType", "a00195.html#ae5fd1329c3ee7b645e1761ed2087b0a0", null ],
    [ "LTI_STS_MrSIDReaders_UnsupportedFileVersion", "a00195.html#a9144cec7e4b5047b9210343def29be43", null ],
    [ "LTI_STS_MrSIDReaders_UnsupportedLidarFile", "a00195.html#ae1743c6435bc4d2311110a1e2d5c66cb", null ]
];