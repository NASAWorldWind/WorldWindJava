var a00220 =
[
    [ "MrSIDImageReaderInterface", "a00110.html", "a00110" ],
    [ "MrSIDSingleImageReaderBase", "a00114.html", "a00114" ],
    [ "MrSIDMemoryUsage", "a00220.html#af4b0e31cf28c3edf1f7d24fdcc7dea90", [
      [ "MRSID_MEMORY_USAGE_INVALID", "a00220.html#af4b0e31cf28c3edf1f7d24fdcc7dea90a3cee080195a4aad1fa01644276f4b2aa", null ],
      [ "MRSID_MEMORY_USAGE_DEFAULT", "a00220.html#af4b0e31cf28c3edf1f7d24fdcc7dea90a56c7b70f32d24350f4afa8f3c7f2c2a0", null ],
      [ "MRSID_MEMORY_USAGE_SMALL", "a00220.html#af4b0e31cf28c3edf1f7d24fdcc7dea90add27645edede9274660ddb8347d750e7", null ],
      [ "MRSID_MEMORY_USAGE_MEDIUM", "a00220.html#af4b0e31cf28c3edf1f7d24fdcc7dea90a5c0f443c5567703e88317aa4cc009a82", null ],
      [ "MRSID_MEMORY_USAGE_LARGE", "a00220.html#af4b0e31cf28c3edf1f7d24fdcc7dea90a6983b28f5d3abad095fd449691887206", null ]
    ] ],
    [ "MrSIDStreamUsage", "a00220.html#ad7ec5a9b594728fbd482cf963c9b39d2", [
      [ "MRSID_STREAM_USAGE_INVALID", "a00220.html#ad7ec5a9b594728fbd482cf963c9b39d2a5f5087fa08c3576c9305aec638eceaa4", null ],
      [ "MRSID_STREAM_USAGE_KEEPOPEN", "a00220.html#ad7ec5a9b594728fbd482cf963c9b39d2a807ce803faa1ab7953176a6016b43977", null ],
      [ "MRSID_STREAM_USAGE_KEEPCLOSED", "a00220.html#ad7ec5a9b594728fbd482cf963c9b39d2ad40c45154c98d358bd75602705acf4a8", null ],
      [ "MRSID_STREAM_USAGE_DEFAULT", "a00220.html#ad7ec5a9b594728fbd482cf963c9b39d2a52db558e27c21312042474394192fc19", null ]
    ] ]
];