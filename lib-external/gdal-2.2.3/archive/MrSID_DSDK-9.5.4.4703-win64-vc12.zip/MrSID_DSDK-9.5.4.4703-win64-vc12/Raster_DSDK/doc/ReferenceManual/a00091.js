var a00091 =
[
    [ "getMaxDynamicRange", "a00091.html#a4a99379ea576165820f8c88755346ff1", null ],
    [ "getMinDynamicRange", "a00091.html#a8b263e42fd21ff212c0ba5aaebec206e", null ],
    [ "getPixelProps", "a00091.html#a220ecd39939ad95b5f1f7cb73118d870", null ],
    [ "overrideDynamicRange", "a00091.html#a5c1c6e0a43a864e9793a565e63f57113", null ],
    [ "overridePixelBPS", "a00091.html#a44a8266257d867768b54e4dfa5258f9c", null ]
];