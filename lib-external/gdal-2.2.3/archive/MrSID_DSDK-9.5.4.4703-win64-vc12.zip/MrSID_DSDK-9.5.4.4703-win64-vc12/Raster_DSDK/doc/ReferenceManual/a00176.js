var a00176 =
[
    [ "LT_STS_GeoMetadata_ReprojectionErr", "a00176.html#a1623320221ceffefccdddad02e41e0ec", null ],
    [ "LTI_STS_GeoMetadata_BadGeoTIFFDir", "a00176.html#aa4789ec98a76ec72451b46d78dff33bb", null ],
    [ "LTI_STS_GeoMetadata_BadTIFFIFDRead", "a00176.html#a3cfa7eb5974466e406bbeb00ab934454", null ],
    [ "LTI_STS_GeoMetadata_BadTIFFIFDWrite", "a00176.html#a2bd49ef0477b2be3de5bcaf58cb30039", null ],
    [ "LTI_STS_GeoMetadata_Base", "a00176.html#ac840e270efc2685acbb2efe0f428b136", null ],
    [ "LTI_STS_GeoMetadata_CouldNotCreateTransformer", "a00176.html#ab6c1fbce44351ac640e06fcfaa31dfe7", null ],
    [ "LTI_STS_GeoMetadata_GDALDATANotSet", "a00176.html#a11fd516a2b14cfa57b7065b3ba0385dd", null ],
    [ "LTI_STS_GeoMetadata_InvalidDOQMetadata", "a00176.html#ad4c45bd4061303428bcd8647c3151908", null ],
    [ "LTI_STS_GeoMetadata_InvalidSRS", "a00176.html#ae9cf9fddc830553f45527811be4f3fc6", null ],
    [ "LTI_STS_GeoMetadata_InvalidWKT", "a00176.html#a603ead62b2de4c650b4e8b8b652be120", null ],
    [ "LTI_STS_GeoMetadata_MalformedMGRS", "a00176.html#a7c3bf1efcef8b7ede88502a4db7b1524", null ],
    [ "LTI_STS_GeoMetadata_Max", "a00176.html#a1df1a8a9f55112c434856b2133ae2076", null ],
    [ "LTI_STS_GeoMetadata_NITFMGRSError", "a00176.html#aef256d7dc36f5fc66c66f1dbd582811d", null ],
    [ "LTI_STS_GeoMetadata_NITFUnsupIGEOLO", "a00176.html#a697ac6a418bee2bda924e75344bc9a40", null ],
    [ "LTI_STS_GeoMetadata_PROJSONotSet", "a00176.html#ad7ca5365f116ea3dfd322361f36641a0", null ]
];