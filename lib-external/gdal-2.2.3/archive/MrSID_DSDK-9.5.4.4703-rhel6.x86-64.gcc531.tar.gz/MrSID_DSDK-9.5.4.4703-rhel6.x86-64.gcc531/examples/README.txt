Examples for LizardTech LiDAR SDK

The example applications must be run from within this directory,
as they contain hard-coded references to files within the data dir.
