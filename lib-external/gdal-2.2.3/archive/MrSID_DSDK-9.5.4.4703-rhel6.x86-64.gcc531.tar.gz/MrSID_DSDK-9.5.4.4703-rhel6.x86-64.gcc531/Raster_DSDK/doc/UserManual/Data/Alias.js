var xmlAliasData = "";
xmlAliasData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlAliasData += '<CatapultAliasFile DefaultSkinName=\"dsdk\" />';
CMCXmlParser._FilePathToXmlStringMap.Add('Alias', xmlAliasData);
